:HL["/_next/static/chunks/1whri1hs1ufj2.css","style"]
:HL["/_next/static/media/fba5a26ea33df6a3-s.p.18rizl4rsrl42.woff2","font",{"crossOrigin":"","type":"font/woff2"}]
:HL["/health.png","image"]
0:{"tree":{"name":"","param":null,"prefetchHints":4176,"slots":{"children":{"name":"signup","param":null,"prefetchHints":4192,"slots":{"children":{"name":"__PAGE__","param":null,"prefetchHints":4256,"slots":null}}}}},"staleTime":300,"buildId":"_8_Dae8bDcGRP-m3f-0Hh"}
