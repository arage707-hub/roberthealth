var R=require("../../chunks/ssr/[turbopack]_runtime.js")("server/app/_global-error/page.js")
R.c("server/chunks/ssr/node_modules__pnpm_1o-7utr._.js")
R.c("server/chunks/ssr/[root-of-the-server]__0h_yw5x._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1uu2hq3._.js")
R.c("server/chunks/ssr/[root-of-the-server]__1h04fgn._.js")
R.c("server/chunks/ssr/04rc_next_dist_client_components_builtin_global-error_1mbeprf.js")
R.c("server/chunks/ssr/_next-internal_server_app__global-error_page_actions_0zi5s8-.js")
R.m(27879)
module.exports=R.m(27879).exports
