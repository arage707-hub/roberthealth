globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/_8_Dae8bDcGRP-m3f-0Hh/_buildManifest.js",
    "static/_8_Dae8bDcGRP-m3f-0Hh/_ssgManifest.js",
    "static/_8_Dae8bDcGRP-m3f-0Hh/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/38y6ss6uy1f5i.js",
    "static/chunks/2gtcql-sgyx3k.js",
    "static/chunks/1xtpo6etmeyn1.js",
    "static/chunks/0g39r81krea7z.js",
    "static/chunks/turbopack-1xtd7bsq_7-xg.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {},
  "chunkLoadingGlobal": "TURBOPACK"
};
