module.exports=[39321,(a,b,c)=>{}];

//# sourceMappingURL=_next-internal_server_app_health-assessment_page_actions_15mdxgs.js.map