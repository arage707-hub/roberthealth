"use client"

import { useEffect, useState } from "react"
import { useTheme } from "next-themes"
import { Search, Sun, Moon, Mail, Bell } from "lucide-react"
import { UserAvatar } from "./user-avatar"
import { cn } from "@/lib/utils"

export function TopBar() {
  const { resolvedTheme, setTheme } = useTheme()
  const [mounted, setMounted] = useState(false)

  useEffect(() => setMounted(true), [])

  const dark = mounted && resolvedTheme === "dark"

  return (
    <header className="flex flex-wrap items-center gap-4">
      <div className="relative min-w-[220px] flex-1">
        <Search className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-muted-foreground" />
        <input
          type="search"
          placeholder="Search"
          aria-label="Search"
          className="h-11 w-full rounded-full border border-border bg-card pl-11 pr-4 text-sm text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-ring/40"
        />
      </div>

      <div className="flex items-center gap-3">
        <div className="flex items-center gap-2">
          <Sun className="size-4 text-warning" />
          <button
            type="button"
            role="switch"
            aria-checked={dark}
            aria-label="Toggle theme"
            onClick={() => setTheme(dark ? "light" : "dark")}
            className="relative h-6 w-11 rounded-full bg-accent transition-colors"
          >
            <span
              className={cn(
                "absolute top-0.5 size-5 rounded-full bg-primary transition-all",
                dark ? "left-[22px]" : "left-0.5",
              )}
            />
          </button>
          <Moon className="size-4 text-muted-foreground" />
        </div>

        <span className="hidden h-8 w-px bg-border sm:block" />

        <button
          type="button"
          aria-label="Messages"
          className="flex size-10 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
        >
          <Mail className="size-5" />
        </button>
        <button
          type="button"
          aria-label="Notifications"
          className="relative flex size-10 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
        >
          <Bell className="size-5" />
          <span className="absolute right-2 top-2 size-2 rounded-full bg-destructive ring-2 ring-card" />
        </button>

        <span className="hidden h-8 w-px bg-border sm:block" />

        <div className="flex items-center gap-3">
          <div className="hidden text-right sm:block">
            <p className="text-sm font-semibold leading-tight text-foreground">Johan Carter</p>
            <p className="flex items-center justify-end gap-1.5 text-xs text-muted-foreground">
              <span className="size-1.5 rounded-full bg-success" />
              Online
            </p>
          </div>
          <UserAvatar name="Johan Carter" size={42} />
        </div>
      </div>
    </header>
  )
}
