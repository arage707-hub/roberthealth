"use client"

import { FormEvent, useEffect, useRef, useState } from "react"
import { Bot, Plus, Send, Sparkles, User } from "lucide-react"

type Message = {
  id: number
  role: "assistant" | "user"
  text: string
}

const starterMessages: Message[] = [
  {
    id: 1,
    role: "assistant",
    text: "Hi Johan! I’m your personal health assistant. Ask me about your assessment, daily habits, nutrition, fitness, or anything else related to your wellbeing.",
  },
]

const suggestions = [
  "Summarize my health assessment",
  "How can I improve my nutrition score?",
  "Create a simple exercise plan",
]

export function AiChat() {
  const [messages, setMessages] = useState(starterMessages)
  const [input, setInput] = useState("")
  const chatRef = useRef<HTMLElement>(null)
  const [composerPosition, setComposerPosition] = useState<{ left: number; width: number } | null>(null)

  useEffect(() => {
    const chat = chatRef.current
    if (!chat) return

    function updateComposerPosition() {
      const bounds = chat!.getBoundingClientRect()
      setComposerPosition({ left: bounds.left, width: bounds.width })
    }

    updateComposerPosition()
    const observer = new ResizeObserver(updateComposerPosition)
    observer.observe(chat)
    window.addEventListener("resize", updateComposerPosition)
    window.addEventListener("scroll", updateComposerPosition, true)

    return () => {
      observer.disconnect()
      window.removeEventListener("resize", updateComposerPosition)
      window.removeEventListener("scroll", updateComposerPosition, true)
    }
  }, [])

  function sendMessage(text: string) {
    const value = text.trim()
    if (!value) return

    setMessages((current) => [
      ...current,
      { id: Date.now(), role: "user", text: value },
      {
        id: Date.now() + 1,
        role: "assistant",
        text: "Thanks for sharing that. I can help you turn this into practical next steps. The AI response service can be connected here when your backend endpoint is ready.",
      },
    ])
    setInput("")
  }

  function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    sendMessage(input)
  }

  return (
    <section ref={chatRef} className="flex h-full min-h-0 flex-1 flex-col overflow-hidden rounded-[1.75rem] border border-border bg-card pb-28 shadow-sm">
      <header className="shrink-0 flex items-center justify-between border-b border-border px-5 py-4">
        <div className="flex items-center gap-3">
          <div className="flex size-10 items-center justify-center rounded-xl bg-primary text-primary-foreground">
            <Bot className="size-5" />
          </div>
          <div>
            <h1 className="font-semibold text-foreground">Health AI Assistant</h1>
            <p className="flex items-center gap-1.5 text-xs text-muted-foreground">
              <span className="size-1.5 rounded-full bg-success" /> Online and ready to help
            </p>
          </div>
        </div>
        <button
          type="button"
          onClick={() => setMessages(starterMessages)}
          className="flex items-center gap-2 rounded-full border border-border px-3 py-2 text-sm font-medium text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
        >
          <Plus className="size-4" />
          <span className="hidden sm:inline">New chat</span>
        </button>
      </header>

      <div className="scrollbar-hidden flex min-h-0 flex-1 flex-col overflow-y-auto px-4 py-6 sm:px-7">
        <div className="mx-auto flex w-full max-w-3xl flex-1 flex-col gap-5">
          {messages.map((message) => (
            <div
              key={message.id}
              className={`flex gap-3 ${message.role === "user" ? "flex-row-reverse" : ""}`}
            >
              <div
                className={`flex size-9 shrink-0 items-center justify-center rounded-full ${
                  message.role === "assistant"
                    ? "bg-primary text-primary-foreground"
                    : "bg-accent text-accent-foreground"
                }`}
              >
                {message.role === "assistant" ? <Sparkles className="size-4" /> : <User className="size-4" />}
              </div>
              <div
                className={`max-w-[82%] rounded-2xl px-4 py-3 text-sm leading-6 ${
                  message.role === "assistant"
                    ? "rounded-tl-md bg-secondary text-foreground"
                    : "rounded-tr-md bg-primary text-primary-foreground"
                }`}
              >
                {message.text}
              </div>
            </div>
          ))}

          {messages.length === 1 ? (
            <div className="grid gap-2 pt-2 sm:grid-cols-3">
              {suggestions.map((suggestion) => (
                <button
                  key={suggestion}
                  type="button"
                  onClick={() => sendMessage(suggestion)}
                  className="rounded-2xl border border-border bg-background p-3 text-left text-xs font-medium leading-5 text-foreground transition-colors hover:border-primary/40 hover:bg-accent"
                >
                  {suggestion}
                </button>
              ))}
            </div>
          ) : null}
        </div>
      </div>

      <div
        className="fixed bottom-0 z-40 border-t border-border bg-card/95 p-3 shadow-[0_-12px_35px_-18px_rgba(0,0,0,0.4)] backdrop-blur sm:px-7 sm:pb-4"
        style={composerPosition ? { left: composerPosition.left, width: composerPosition.width } : { visibility: "hidden" }}
      >
        <form onSubmit={handleSubmit} className="mx-auto flex max-w-3xl items-end gap-2 rounded-2xl border border-border bg-background p-2 shadow-sm focus-within:ring-2 focus-within:ring-ring/30">
          <textarea
            value={input}
            onChange={(event) => setInput(event.target.value)}
            onKeyDown={(event) => {
              if (event.key === "Enter" && !event.shiftKey) {
                event.preventDefault()
                sendMessage(input)
              }
            }}
            rows={1}
            placeholder="Message your health assistant..."
            aria-label="Chat message"
            className="max-h-32 min-h-10 flex-1 resize-none bg-transparent px-3 py-2 text-sm text-foreground outline-none placeholder:text-muted-foreground"
          />
          <button
            type="submit"
            disabled={!input.trim()}
            aria-label="Send message"
            className="flex size-10 shrink-0 items-center justify-center rounded-xl bg-primary text-primary-foreground transition-opacity disabled:cursor-not-allowed disabled:opacity-40"
          >
            <Send className="size-4" />
          </button>
        </form>
        <p className="mt-2 text-center text-[11px] text-muted-foreground">AI can make mistakes. Verify important health information.</p>
      </div>
    </section>
  )
}
