"use client"

import { useEffect, useState } from "react"
import { useRouter } from "next/navigation"
import { CheckCircle2 } from "lucide-react"
import { Sidebar } from "@/components/dashboard/sidebar"
import { TopBar } from "@/components/dashboard/top-bar"
import { StatCards } from "@/components/dashboard/stat-cards"
import { PatientsStatistics } from "@/components/dashboard/patients-statistics"
import { WorkingHours } from "@/components/dashboard/working-hours"
import { AppointmentsTable } from "@/components/dashboard/appointments-table"
import { SchedulePanel } from "@/components/dashboard/schedule-panel"
import { AiChat } from "@/components/dashboard/ai-chat"

export function DashboardPage() {
  const router = useRouter()
  const [showAssessmentPrompt, setShowAssessmentPrompt] = useState(false)
  const [isHydrated, setIsHydrated] = useState(false)
  const [activeView, setActiveView] = useState("Dashboard")
  const [submissionConfirmed, setSubmissionConfirmed] = useState(false)

  useEffect(() => {
    setIsHydrated(true)
    const completed = localStorage.getItem("healthAssessmentCompleted") === "true"
    setShowAssessmentPrompt(!completed)
    if (sessionStorage.getItem("assessmentSubmissionConfirmed") === "true") {
      sessionStorage.removeItem("assessmentSubmissionConfirmed")
      setSubmissionConfirmed(true)
    }
  }, [])

  function handleStartAssessment() {
    localStorage.setItem("healthAssessmentCompleted", "false")
    router.push("/health-assessment")
  }

  return (
    <div className="relative">
      <div className={showAssessmentPrompt ? "filter blur-sm transition-all duration-300" : ""}>
        <div className="h-dvh overflow-hidden p-3 md:p-5">
          <div className="mx-auto flex h-full max-w-[1600px] gap-4 overflow-hidden rounded-[2rem] bg-secondary/40 p-3 md:p-4">
            <Sidebar active={activeView} onNavigate={setActiveView} contained />

            <div className="grid h-full min-h-0 min-w-0 flex-1 grid-cols-1 gap-5 overflow-hidden xl:grid-cols-[1fr_360px]">
              {/* Main column */}
              <main className={`scrollbar-hidden flex h-full min-h-0 min-w-0 flex-col gap-5 ${activeView === "AI Chat" ? "overflow-hidden" : "overflow-y-auto pr-1"}`}>
                <TopBar />
                {activeView === "AI Chat" ? (
                  <AiChat />
                ) : (
                  <>
                    <StatCards />
                    <div className="grid grid-cols-1 gap-5 lg:grid-cols-[1.6fr_1fr]">
                      <PatientsStatistics />
                      <WorkingHours />
                    </div>
                    <AppointmentsTable />
                  </>
                )}
              </main>

              {/* Schedule sidebar */}
              <div className="h-full min-h-0 min-w-0 overflow-hidden">
                <SchedulePanel contained />
              </div>
            </div>
          </div>
        </div>
      </div>

      {isHydrated && showAssessmentPrompt ? (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-background/80 px-4 backdrop-blur-sm">
          <div className="w-full max-w-4xl rounded-[2rem] border border-border bg-card p-0 shadow-2xl overflow-hidden">
            <div className="grid grid-cols-1 md:grid-cols-2">
              {/* Left image */}
              <div className="h-72 md:h-auto">
                <img src="/nut-female.jpg" alt="Assessment" className="h-full w-full object-cover" />
              </div>

              {/* Right content */}
              <div className="flex flex-col p-6 md:p-8">
                <div className="flex">
                  <img src="/health.png" alt="healthiphy" className="h-12 w-auto rounded-md object-contain" />
                </div>

                <div className="mt-4 flex-1">
                  <p className="text-sm font-semibold uppercase tracking-[0.3em] text-primary/90">Action required</p>
                  <h1 className="mt-3 text-2xl font-bold tracking-tight text-foreground sm:text-3xl">
                    Complete your health assessment
                  </h1>
                  <p className="mt-4 text-sm leading-7 text-muted-foreground">
                    Before you continue, please complete the assessment to help us personalize your dashboard insights.
                  </p>
                </div>

                <div className="mt-6 flex items-center justify-start">
                  <button
                    type="button"
                    onClick={handleStartAssessment}
                    className="inline-flex items-center justify-center rounded-full bg-primary px-6 py-2 text-sm font-semibold text-primary-foreground transition-opacity hover:opacity-90"
                  >
                    Yes, take assessment
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      ) : null}

      {submissionConfirmed ? (
        <div role="status" className="fixed right-4 top-4 z-[60] flex max-w-sm items-center gap-3 rounded-2xl border border-success/25 bg-card px-4 py-3 text-sm font-medium text-card-foreground shadow-xl">
          <CheckCircle2 className="size-5 shrink-0 text-success" />
          <span>Your assessment and all answers were submitted successfully.</span>
          <button type="button" onClick={() => setSubmissionConfirmed(false)} aria-label="Dismiss confirmation" className="ml-2 text-lg leading-none text-muted-foreground hover:text-foreground">
            ×
          </button>
        </div>
      ) : null}
    </div>
  )
}
