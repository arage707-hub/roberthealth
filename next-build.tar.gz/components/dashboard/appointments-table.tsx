"use client"

import { useState } from "react"
import { Checkbox } from "@/components/ui/checkbox"

type Choice = {
  id: string
  title: string
  subtitle?: string
  tags?: string[]
  severity?: string
  frequency?: string
}

const choices: Choice[] = [
  {
    id: "1",
    title: "Increase meal frequency to 3 - 4 balanced meals per day to stabilize energy levels",
    subtitle: "AI Insight • Daily",
    tags: ["Nutrition Choices"],
    severity: "High",
    frequency: "Daily",
  },
  {
    id: "2",
    title: "Quit smoking immediately; consult a provider for cessation programs",
    subtitle: "AI Insight • Daily",
    tags: ["Toxin Choices"],
    severity: "High",
    frequency: "Daily",
  },
  {
    id: "3",
    title: "Schedule a 10-minute daily mindfulness exercise (deep breathing or guided meditation)",
    subtitle: "AI Insight • Daily",
    tags: ["Mental Choices"],
    severity: "High",
    frequency: "Daily",
  },
  {
    id: "4",
    title: "Establish a consistent sleep schedule by going to bed and waking at the same time",
    subtitle: "AI Insight • Daily",
    tags: ["Physical Choices"],
    severity: "High",
    frequency: "Daily",
  },
  {
    id: "5",
    title: "Schedule a consultation with a genetic counselor to discuss potential benefits",
    subtitle: "AI Insight • Daily",
    tags: ["Genetic Choices"],
    severity: "High",
    frequency: "Daily",
  },
  {
    id: "6",
    title: "Schedule an annual wellness visit with your primary care provider",
    subtitle: "AI Insight • Daily",
    tags: ["Medical Choices"],
    severity: "High",
    frequency: "Daily",
  },
]

export function AppointmentsTable() {
  const [selected, setSelected] = useState<string[]>([])
  const allSelected = selected.length === choices.length

  const toggleAll = () => setSelected(allSelected ? [] : choices.map((c) => c.id))
  const toggle = (id: string) =>
    setSelected((s) => (s.includes(id) ? s.filter((x) => x !== id) : [...s, id]))

  return (
    <section className="flex flex-col rounded-3xl border border-border bg-card p-5">
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Health Choices</h2>
          <p className="text-sm text-muted-foreground">{selected.length}/{choices.length} done</p>
        </div>
        <div className="ml-auto flex items-center gap-2">
          <button className="rounded-full border border-border px-3 py-1 text-sm">All pathways</button>
        </div>
      </div>

      <div className="mt-4 flex flex-col gap-3">
        {choices.map((c) => {
          const checked = selected.includes(c.id)
          return (
            <div
              key={c.id}
              className={`flex items-start gap-4 rounded-lg border border-border bg-card p-3 ${
                checked ? "bg-accent/30" : ""
              }`}
            >
              <div className="pt-1">
                <Checkbox checked={checked} onCheckedChange={() => toggle(c.id)} aria-label={c.title} />
              </div>

              <div className="flex flex-col flex-1">
                <div className="flex items-center justify-between gap-2">
                  <p className="font-medium text-foreground">{c.title}</p>
                  <div className="flex items-center gap-2">
                    <span className="rounded-full bg-muted/60 px-2 py-0.5 text-xs">{c.severity}</span>
                    <span className="rounded-full bg-muted/20 px-2 py-0.5 text-xs">{c.frequency}</span>
                  </div>
                </div>
                {c.subtitle && <p className="mt-1 text-sm text-muted-foreground">{c.subtitle}</p>}

                <div className="mt-2 flex flex-wrap items-center gap-2">
                  {c.tags?.map((t) => (
                    <span key={t} className="inline-flex items-center gap-1 rounded-full bg-white/5 px-2 py-0.5 text-xs text-muted-foreground">
                      {t}
                    </span>
                  ))}
                </div>
              </div>

              <div className="flex flex-col items-end gap-2">
                <div className="text-xs text-muted-foreground">AI Insight</div>
                <div className="flex items-center gap-2">
                  <button className="text-muted-foreground hover:text-foreground">⟳</button>
                  <button className="text-muted-foreground hover:text-foreground">✖</button>
                </div>
              </div>
            </div>
          )
        })}
      </div>

      <div className="mt-4 border-t border-border pt-3 text-xs text-muted-foreground">
        Choices come from your AI Insights. Double-tap to see supplements.
      </div>
    </section>
  )
}
