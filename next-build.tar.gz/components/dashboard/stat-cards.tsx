import { ArrowUpRight, UserRound, Users, BedDouble } from "lucide-react"

function CardShell({
  icon,
  title,
  children,
}: {
  icon: React.ReactNode
  title: string
  children: React.ReactNode
}) {
  return (
    <div className="flex flex-col rounded-3xl border border-border bg-card p-5">
      <div className="mb-4 flex items-center justify-between">
        <div className="flex items-center gap-2.5">
          <span className="flex size-9 items-center justify-center rounded-full bg-accent text-primary">
            {icon}
          </span>
          <h3 className="text-[15px] font-semibold text-foreground">{title}</h3>
        </div>
        <button
          type="button"
          aria-label={`Open ${title} details`}
          className="flex size-8 items-center justify-center rounded-full border border-border text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
        >
          <ArrowUpRight className="size-4" />
        </button>
      </div>
      {children}
    </div>
  )
}

function Delta({ value }: { value: string }) {
  return (
    <span className="inline-flex items-center gap-1 rounded-full bg-success/15 px-2 py-1 text-xs font-semibold text-success">
      <ArrowUpRight className="size-3" />
      {value}
    </span>
  )
}

export function StatCards() {
  return (
    <div className="grid grid-cols-1 gap-5 sm:grid-cols-2 xl:grid-cols-3">
      <CardShell icon={<UserRound className="size-5" />} title="Body Score">
        <div className="flex items-start justify-between">
          <p className="text-4xl font-bold tracking-tight text-foreground">72</p>
          <div className="text-right">
            <Delta value="16.9%" />
            <p className="mt-1 text-xs text-muted-foreground">vs. last month</p>
          </div>
        </div>
        <p className="mt-4 text-sm leading-relaxed text-muted-foreground">
          Overall health score based on questionnaire results and recent activity.
        </p>
      </CardShell>

      <CardShell icon={<Users className="size-5" />} title="Active Users">
        <div className="flex items-start justify-between">
          <p className="text-4xl font-bold tracking-tight text-foreground">10,000+</p>
          <div className="text-right">
            <Delta value="12.9%" />
            <p className="mt-1 text-xs text-muted-foreground">vs. last month</p>
          </div>
        </div>
        <p className="mt-4 text-sm leading-relaxed text-muted-foreground">People transforming their health daily.</p>
      </CardShell>

      <CardShell icon={<BedDouble className="size-5" />} title="Daily Recommendations">
        <div className="flex items-start justify-between">
          <p className="text-4xl font-bold tracking-tight text-foreground">87%</p>
          <p className="text-sm text-muted-foreground">Success Rate</p>
        </div>
        <p className="mt-4 text-sm leading-relaxed text-muted-foreground">Personalized suggestions to improve nutrition and activity.</p>
      </CardShell>
    </div>
  )
}
