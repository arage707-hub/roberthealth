"use client"

import { MoreVertical, HeartPulse, Stethoscope, CalendarCheck, Activity, Syringe } from "lucide-react"
import { Bar, BarChart, Cell, LabelList, XAxis, YAxis } from "recharts"
import { ChartContainer, type ChartConfig } from "@/components/ui/chart"
import { patientStats } from "@/lib/dashboard-data"

const chartConfig = {
  value: { label: "Patients" },
  emergency: { label: "Emergency Patients", color: "var(--chart-1)" },
  routine: { label: "Routine Check-up", color: "var(--chart-2)" },
  appointment: { label: "Appointment", color: "var(--chart-3)" },
  physical: { label: "Physical Therapy", color: "var(--chart-4)" },
  session: { label: "Therapy Session", color: "var(--chart-5)" },
} satisfies ChartConfig

const legend = [
  { icon: HeartPulse, label: "Body Fat %", color: "var(--color-emergency)" },
  { icon: Stethoscope, label: "Hydration", color: "var(--color-routine)" },
  { icon: CalendarCheck, label: "Protein Intake", color: "var(--color-appointment)" },
  { icon: Activity, label: "Activity Level", color: "var(--color-physical)" },
  { icon: Syringe, label: "Sleep Quality", color: "var(--color-session)" },
]

export function PatientsStatistics() {
  return (
    <section className="flex min-w-0 flex-col rounded-3xl border border-border bg-card p-5">
      <div className="flex items-start justify-between">
        <div>
          <h2 className="text-lg font-semibold text-foreground">Your Health Summary</h2>
          <p className="text-sm text-muted-foreground">After answering the questionnaire: how healthy you are, what to improve, and AI suggestions.</p>
        </div>
        <button
          type="button"
          aria-label="More options"
          className="flex size-8 items-center justify-center rounded-full text-muted-foreground transition-colors hover:bg-accent hover:text-foreground"
        >
          <MoreVertical className="size-4" />
        </button>
      </div>

      <ChartContainer config={chartConfig} className="mt-4 h-[240px] w-full">
        <BarChart data={patientStats} margin={{ top: 28, left: 0, right: 0, bottom: 0 }} barCategoryGap="22%">
          <defs>
            {patientStats.map((d) => (
              <linearGradient key={d.key} id={`grad-${d.key}`} x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor={`var(--color-${d.key})`} stopOpacity={0.95} />
                <stop offset="100%" stopColor={`var(--color-${d.key})`} stopOpacity={0.25} />
              </linearGradient>
            ))}
          </defs>
          <XAxis dataKey="short" tickLine={false} axisLine={false} tick={false} height={0} />
          <YAxis hide domain={[0, 66]} />
          <Bar dataKey="value" radius={[8, 8, 0, 0]}>
            {patientStats.map((d) => (
              <Cell key={d.key} fill={`url(#grad-${d.key})`} stroke={`var(--color-${d.key})`} strokeOpacity={0.4} />
            ))}
            <LabelList
              dataKey="value"
              position="top"
              offset={10}
              className="fill-foreground text-sm font-semibold"
              formatter={(v: number) => `${v}%`}
            />
          </Bar>
        </BarChart>
      </ChartContainer>

      <div className="mt-2 flex flex-wrap gap-x-5 gap-y-2 border-t border-border pt-4">
        {legend.map(({ icon: Icon, label, color }) => (
          <span key={label} className="flex items-center gap-1.5 text-xs text-muted-foreground">
            <span
              className="flex size-5 items-center justify-center rounded-md"
              style={{ backgroundColor: color, opacity: 0.9 }}
            >
              <Icon className="size-3 text-foreground/70" />
            </span>
            {label}
          </span>
        ))}
      </div>
    </section>
  )
}
