export type HealthQuestion = {
  id: number
  category: string
  question: string
  options: string[]
}

export const healthQuestions: HealthQuestion[] = [
  {
    id: 1,
    category: "General",
    question: "How would you rate your overall health right now?",
    options: ["Excellent", "Good", "Fair", "Poor"],
  },
  {
    id: 2,
    category: "Sleep",
    question: "On average, how many hours do you sleep each night?",
    options: ["Less than 5", "5 to 6", "7 to 8", "More than 8"],
  },
  {
    id: 3,
    category: "Sleep",
    question: "How often do you wake up feeling rested?",
    options: ["Almost always", "Often", "Sometimes", "Rarely"],
  },
  {
    id: 4,
    category: "Activity",
    question: "How many days a week do you exercise for 30+ minutes?",
    options: ["5 or more", "3 to 4", "1 to 2", "None"],
  },
  {
    id: 5,
    category: "Activity",
    question: "How much time do you spend sitting on a typical day?",
    options: ["Less than 4 hours", "4 to 6 hours", "6 to 9 hours", "More than 9 hours"],
  },
  {
    id: 6,
    category: "Nutrition",
    question: "How many servings of fruits and vegetables do you eat daily?",
    options: ["5 or more", "3 to 4", "1 to 2", "Almost none"],
  },
  {
    id: 7,
    category: "Nutrition",
    question: "How often do you eat fast food or fried food?",
    options: ["Rarely", "Once a week", "A few times a week", "Most days"],
  },
  {
    id: 8,
    category: "Hydration",
    question: "How many glasses of water do you drink per day?",
    options: ["8 or more", "5 to 7", "2 to 4", "Fewer than 2"],
  },
  {
    id: 9,
    category: "Nutrition",
    question: "How often do you eat sugary snacks or drinks?",
    options: ["Rarely", "A few times a week", "Once a day", "Several times a day"],
  },
  {
    id: 10,
    category: "Lifestyle",
    question: "Do you currently smoke or use tobacco products?",
    options: ["Never", "Quit over a year ago", "Occasionally", "Daily"],
  },
  {
    id: 11,
    category: "Lifestyle",
    question: "How often do you drink alcohol?",
    options: ["Never", "Occasionally", "Weekly", "Daily"],
  },
  {
    id: 12,
    category: "Mental Health",
    question: "How often have you felt stressed in the past two weeks?",
    options: ["Rarely", "Sometimes", "Often", "Almost constantly"],
  },
  {
    id: 13,
    category: "Mental Health",
    question: "How often do you feel down, anxious, or overwhelmed?",
    options: ["Rarely", "Sometimes", "Often", "Almost every day"],
  },
  {
    id: 14,
    category: "Mental Health",
    question: "How connected do you feel to friends and family?",
    options: ["Very connected", "Somewhat connected", "A little isolated", "Very isolated"],
  },
  {
    id: 15,
    category: "General",
    question: "How often do you experience headaches?",
    options: ["Rarely", "Once a month", "Weekly", "Almost daily"],
  },
  {
    id: 16,
    category: "General",
    question: "How would you describe your energy levels during the day?",
    options: ["High and steady", "Generally good", "Often low", "Exhausted"],
  },
  {
    id: 17,
    category: "Heart",
    question: "Do you know your typical blood pressure range?",
    options: ["Yes, it's normal", "Yes, slightly high", "Yes, it's high", "I don't know"],
  },
  {
    id: 18,
    category: "Heart",
    question: "How often do you feel shortness of breath during light activity?",
    options: ["Never", "Rarely", "Sometimes", "Often"],
  },
  {
    id: 19,
    category: "Activity",
    question: "How would you rate your physical strength and mobility?",
    options: ["Excellent", "Good", "Limited", "Very limited"],
  },
  {
    id: 20,
    category: "General",
    question: "How often do you experience back or joint pain?",
    options: ["Rarely", "Occasionally", "Frequently", "Constantly"],
  },
  {
    id: 21,
    category: "Preventive",
    question: "When was your last routine medical check-up?",
    options: ["Within 6 months", "Within a year", "1 to 2 years ago", "More than 2 years"],
  },
  {
    id: 22,
    category: "Preventive",
    question: "How up to date are you with recommended vaccinations?",
    options: ["Fully up to date", "Mostly up to date", "Somewhat behind", "Not sure"],
  },
  {
    id: 23,
    category: "Preventive",
    question: "Do you take any prescribed medication regularly?",
    options: ["None", "One", "Two to three", "Four or more"],
  },
  {
    id: 24,
    category: "Nutrition",
    question: "How often do you skip meals?",
    options: ["Never", "Occasionally", "A few times a week", "Daily"],
  },
  {
    id: 25,
    category: "Lifestyle",
    question: "How many hours of screen time do you have outside of work?",
    options: ["Less than 1", "1 to 2", "3 to 4", "More than 4"],
  },
  {
    id: 26,
    category: "Mental Health",
    question: "How often do you take time to relax or unwind?",
    options: ["Every day", "A few times a week", "Rarely", "Almost never"],
  },
  {
    id: 27,
    category: "Sleep",
    question: "How consistent is your sleep schedule?",
    options: ["Very consistent", "Mostly consistent", "Irregular", "Very irregular"],
  },
  {
    id: 28,
    category: "General",
    question: "How would you rate your immune system this year?",
    options: ["Rarely get sick", "Occasionally sick", "Often sick", "Constantly unwell"],
  },
  {
    id: 29,
    category: "Lifestyle",
    question: "How well do you manage your work-life balance?",
    options: ["Very well", "Fairly well", "Struggling", "Very poorly"],
  },
  {
    id: 30,
    category: "General",
    question: "Overall, how motivated are you to improve your health?",
    options: ["Very motivated", "Somewhat motivated", "A little", "Not right now"],
  },
]
