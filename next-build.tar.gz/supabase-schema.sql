-- Supabase schema for AI health assessment app

-- 1. Profiles table extends auth.users with additional user metadata
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  first_name text,
  last_name text,
  role text default 'user',
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create unique index if not exists profiles_email_idx on profiles(id);

-- 2. Assessments table to store completed assessment sessions
create table if not exists assessments (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  status text not null default 'pending',
  score int null,
  notes text null,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists assessments_user_id_idx on assessments(user_id);

-- 3. Assessment answers table
create table if not exists assessment_answers (
  id uuid primary key default gen_random_uuid(),
  assessment_id uuid references assessments(id) on delete cascade,
  question_id int not null,
  answer text not null,
  created_at timestamptz default now()
);

create index if not exists assessment_answers_assessment_id_idx on assessment_answers(assessment_id);

-- Authenticated users can create and manage only their own assessments.
alter table assessments enable row level security;
alter table assessment_answers enable row level security;

drop policy if exists "Users can read own assessments" on assessments;
create policy "Users can read own assessments"
on assessments for select to authenticated
using (auth.uid() = user_id);

drop policy if exists "Users can create own assessments" on assessments;
create policy "Users can create own assessments"
on assessments for insert to authenticated
with check (auth.uid() = user_id);

drop policy if exists "Users can delete own assessments" on assessments;
create policy "Users can delete own assessments"
on assessments for delete to authenticated
using (auth.uid() = user_id);

drop policy if exists "Users can read own assessment answers" on assessment_answers;
create policy "Users can read own assessment answers"
on assessment_answers for select to authenticated
using (
  exists (
    select 1 from assessments
    where assessments.id = assessment_answers.assessment_id
      and assessments.user_id = auth.uid()
  )
);

drop policy if exists "Users can create own assessment answers" on assessment_answers;
create policy "Users can create own assessment answers"
on assessment_answers for insert to authenticated
with check (
  exists (
    select 1 from assessments
    where assessments.id = assessment_answers.assessment_id
      and assessments.user_id = auth.uid()
  )
);

-- 4. AI jobs table for model / prompt runs
create table if not exists ai_jobs (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  assessment_id uuid references assessments(id) on delete set null,
  status text not null default 'pending',
  result jsonb null,
  prompt text null,
  error text null,
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists ai_jobs_user_id_idx on ai_jobs(user_id);
create index if not exists ai_jobs_assessment_id_idx on ai_jobs(assessment_id);

-- 5. Optional user feedback table
create table if not exists assessment_feedback (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references auth.users(id) on delete cascade,
  assessment_id uuid references assessments(id) on delete cascade,
  rating int null,
  comments text null,
  created_at timestamptz default now()
);

create index if not exists assessment_feedback_user_id_idx on assessment_feedback(user_id);
create index if not exists assessment_feedback_assessment_id_idx on assessment_feedback(assessment_id);
